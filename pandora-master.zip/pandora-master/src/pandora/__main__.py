# -*- coding: utf-8 -*-

from pandora import launcher

if __name__ == '__main__':
    launcher.run()
